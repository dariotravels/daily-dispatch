# The Daily Dispatch — push-button newspaper

A Streamlit app that creates a fresh seven-page modern PDF newspaper with:
1. Front page
2. U.S. & World News
3. Aviation
4. Travel
5. Las Vegas & Henderson
6. Lorain County, Ohio (Lorain, Vermilion, Elyria)
7. Weather (Las Vegas/Henderson and Lorain County)

## Run locally
Install Python 3.10+ and run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Use it from an iPhone (recommended)
1. Create a free GitHub repository and upload `app.py` and `requirements.txt`.
2. Visit https://share.streamlit.io and sign in with GitHub.
3. Create a new app, choose the repository, branch `main`, and main file `app.py`.
4. Once deployed, open the app's URL in Safari on your iPhone.
5. Tap Share → Add to Home Screen for an app-like shortcut.
6. Tap **Generate Today's Edition** whenever you want a new PDF.

**Note:** This is not yet hosted. It needs a one-time deployment. Public Streamlit apps may be discoverable by URL; avoid adding personal or confidential data. RSS availability and network access vary. Google News RSS headlines and short feed summaries are used, with clickable source links. The app does not produce original reporting or reproduce full copyrighted articles. Weather comes from Open-Meteo.
